/**
 * <p>****************************************************************************</p>
 * <p><b>Copyright © 2010-2019 soho team All Rights Reserved<b></p>
 * <ul style="margin:15px;">
 * <li>Description : </li>
 * <li>Version     : 1.0</li>
 * <li>Creation    : 2019年09月15日</li>
 * <li>@author     : ____′↘夏悸</li>
 * </ul>
 * <p>****************************************************************************</p>
 */
import {Monitor} from './js/common/js-sdk-perf.esm.min.js';

new Monitor().init({
	id: "Jyy3ZiYIVUGkPqpv", sendSpaPv: true,
});

