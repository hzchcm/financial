import ECharts from './echarts';

export default ECharts;
